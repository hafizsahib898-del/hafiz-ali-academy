import React, { useEffect, useState } from "react";
import {
  Menu, X, BookOpen, Sparkles, Clock, Globe2, BadgeCheck, Star, MessageCircle,
  Youtube, Facebook, Music2, ChevronDown, CheckCircle2, GraduationCap, HeartHandshake,
  Home, Layers, CalendarCheck, Play, ShieldCheck, Users, Phone
} from "lucide-react";

const YOUTUBE = "https://" + "youtube.com/@hafizsahib-xx9ex";
const WHATSAPP_CHANNEL = "https://" + "whatsapp.com/channel/0029VbEnlWp0bIdnAuFqly0Q";
const TIKTOK = "https://" + "tiktok.com/@hafizaliquranacademy";
const FACEBOOK = "https://" + "facebook.com/share/18zy1GLYkY";
const WHATSAPP_CHAT = "https://wa.me/923136793394";

const courses = [
  { n: "01", icon: BookOpen, title: "Noorani Qaida", desc: "Arabic letters, sounds and joining, step by step for complete beginners.", tag: "Best for beginners" },
  { n: "02", icon: BookOpen, title: "Quran Reading", desc: "Read the Quran fluently and correctly with guided practice and kind correction.", tag: "Build fluency" },
  { n: "03", icon: Sparkles, title: "Quran with Tajweed", desc: "Improve pronunciation and apply the rules of Tajweed with confidence.", tag: "Perfect pronunciation" },
  { n: "04", icon: GraduationCap, title: "Hifz-ul-Quran", desc: "A structured memorisation plan with daily revision and steady progress.", tag: "Structured memorisation" },
  { n: "05", icon: HeartHandshake, title: "Daily Duas & Salah", desc: "Everyday duas and how to pray Salah correctly, learned with love.", tag: "Daily practice" },
  { n: "06", icon: Layers, title: "Islamic Studies", desc: "Basics of faith, manners and life of the Prophet (PBUH).", tag: "Faith & manners" },
];

const why = [
  { icon: Users, title: "Personalised Learning", text: "One-to-one attention, paced around your child and your goals." },
  { icon: Clock, title: "Flexible Class Timings", text: "Morning, evening and weekend slots that fit school and family life." },
  { icon: Globe2, title: "Learn from Anywhere", text: "Join from home, wherever your family lives in the world." },
  { icon: BadgeCheck, title: "Affordable Fees", text: "Clear monthly fees, no hidden charges and a free trial first." },
];

const testimonials = [
  { name: "Parent of a young learner", role: "Noorani Qaida", quote: "My child now recognises letters with confidence and looks forward to every class. The teacher is patient and encouraging." },
  { name: "Mother of two students", role: "Quran Reading", quote: "Both children improved so quickly. Lessons are calm, structured and easy to follow from home." },
  { name: "Adult student", role: "Quran with Tajweed", quote: "I started as a complete beginner. Now I read with much better pronunciation and I finally feel confident." },
  { name: "Parent of a Hifz student", role: "Hifz-ul-Quran", quote: "The daily revision plan keeps memorisation strong. We can see steady progress every single week." },
  { name: "Family learning together", role: "Daily Duas & Salah", quote: "Our whole family has learned new duas. The classes are warm, respectful and beautifully organised." },
];

const plans = [
  { name: "2 Days / Week", price: 20, classes: 8, hours: 4, note: "A gentle start" },
  { name: "3 Days / Week", price: 35, classes: 12, hours: 6, note: "Steady progress" },
  { name: "4 Days / Week", price: 50, classes: 16, hours: 8, note: "Most popular rhythm", recommended: true },
  { name: "5 Days / Week", price: 65, classes: 20, hours: 10, note: "Fast, focused learning" },
  { name: "6 Days / Week", price: 80, classes: 24, hours: 12, note: "For dedicated learners" },
  { name: "Saturday Only", price: 20, classes: 4, hours: 2, note: "Weekend learning" },
  { name: "Sunday Only", price: 20, classes: 4, hours: 2, note: "Weekend learning" },
  { name: "Saturday & Sunday", price: 40, classes: 8, hours: 4, note: "Both weekend days" },
];

const rates: Record<string, { symbol: string; rate: number; label: string }> = {
  USD: { symbol: "$", rate: 1, label: "USD — US Dollar" },
  EUR: { symbol: "€", rate: 0.92, label: "EUR — Euro" },
  GBP: { symbol: "£", rate: 0.79, label: "GBP — British Pound" },
  AUD: { symbol: "A$", rate: 1.52, label: "AUD — Australian Dollar" },
};

const faqs = [
  { q: "How do I book a trial?", a: "Fill in the Free Trial form below and press Send via WhatsApp. We will confirm your free class, course and timing." },
  { q: "Can students learn from different countries?", a: "Yes. Students join from many countries and time zones. We arrange a class time that works for your family." },
  { q: "What are monthly fees?", a: "Fees depend on how many days you study each week. Every plan includes 30-minute lessons and clear monthly pricing. Your first class is a free trial." },
  { q: "Are beginner students welcome?", a: "Absolutely. Beginners start with Noorani Qaida and move forward step by step, at a comfortable pace." },
];

const socials = [
  { label: "YouTube", href: YOUTUBE, icon: Youtube, note: "@hafizsahib-xx9ex" },
  { label: "WhatsApp Channel", href: WHATSAPP_CHANNEL, icon: MessageCircle, note: "Follow our channel" },
  { label: "Facebook", href: FACEBOOK, icon: Facebook, note: "Follow on Facebook" },
  { label: "TikTok", href: TIKTOK, icon: Music2, note: "@hafizaliquranacademy" },
];

type TrialForm = { student: string; parent: string; age: string; country: string; whatsapp: string; email: string; course: string; schedule: string; time: string; message: string };
const emptyForm: TrialForm = { student: "", parent: "", age: "", country: "", whatsapp: "", email: "", course: "", schedule: "", time: "", message: "" };

async function callApi(action: string, args: Record<string, unknown>) {
  const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, args }) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json?.error) throw new Error(json?.error || `Request failed (${res.status})`);
  return json.data;
}

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [currency, setCurrency] = useState("USD");
  const [form, setForm] = useState<TrialForm>(emptyForm);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [busy, setBusy] = useState(false);
  const [saveStatus, setSaveStatus] = useState("");
  const [savedCount, setSavedCount] = useState(0);
  const [socialOpen, setSocialOpen] = useState(false);
  const [showAllReviews, setShowAllReviews] = useState(false);

  async function reloadRecords() {
    try {
      const data = await callApi("records.list", { collection: "trial_requests" });
      if (Array.isArray(data?.records)) setSavedCount(data.records.length);
    } catch { /* records service is unavailable in preview; the form still opens WhatsApp */ }
  }
  useEffect(() => { reloadRecords(); }, []);

  function set(key: keyof TrialForm, value: string) { setForm((f) => ({ ...f, [key]: value })); }

  async function submitTrial(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    const required: Array<keyof TrialForm> = ["student", "parent", "age", "country", "whatsapp", "email", "course", "schedule", "time"];
    if (required.some((k) => !form[k].trim())) { setSaveStatus("Please complete all required fields before sending."); return; }
    const lines = [
      "Assalam-o-Alaikum! I would like to book a Free Trial Class.",
      "", `Student Name: ${form.student}`, `Parent / Guardian Name: ${form.parent}`, `Student Age: ${form.age}`, `Country: ${form.country}`,
      `WhatsApp Number: ${form.whatsapp}`, `Email: ${form.email}`, `Selected Course: ${form.course}`, `Preferred Weekly Schedule: ${form.schedule}`,
      `Preferred Class Time and Time Zone: ${form.time}`, form.message.trim() ? `Additional Message: ${form.message}` : "",
    ].filter(Boolean).join("\n");
    const waUrl = `${WHATSAPP_CHAT}?text=${encodeURIComponent(lines)}`;
    setBusy(true); setSaveStatus("Saving your trial request…");
    try {
      await callApi("records.create", { collection: "trial_requests", value: { ...form, created_label: "Free trial request", status: "new" }, idempotency_key: `trial-${form.student.trim().toLowerCase()}-${form.whatsapp.trim()}-${form.course}-${Date.now()}` });
      await reloadRecords();
      setSaveStatus("Your trial request is saved. Opening WhatsApp now — please press send there to complete your booking.");
      setForm(emptyForm);
    } catch (err) {
      setSaveStatus("We could not save this request in the site records, but your WhatsApp message is ready — please press send there to complete your booking.");
    } finally { setBusy(false); }
    window.open(waUrl, "_blank", "noopener");
  }

  const rate = rates[currency];
  const nav = [["Courses", "#courses"], ["Why Us", "#why"], ["Fees", "#fees"], ["How It Works", "#how"], ["FAQ", "#faq"], ["Contact", "#contact"]];

  return (
    <div data-safe-area-inset-root style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" }} className="min-h-screen bg-[var(--bg)] text-white overflow-x-clip">
      {/* STICKY HEADER */}
      <header data-safe-area-sticky-top style={{ top: "var(--safe-area-inset-top)" }} className="sticky z-40 bg-[#073325]/95 backdrop-blur border-b border-[var(--line)]">
        <div className="bg-[#05281E] px-4 py-2">
          <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
            <span className="text-[11px] sm:text-xs tracking-[0.18em] uppercase text-[#E8C766] font-bold">Follow Us</span>
            <div className="flex items-center gap-1.5">
              {socials.map((s) => <a key={s.label} href={s.href} target="_blank" rel="noopener" aria-label={`Follow on ${s.label}`} className="w-8 h-8 rounded-full border border-[var(--line)] grid place-items-center text-[#E8C766] hover:bg-[var(--gold)] hover:text-[#0B3D2E] transition"><s.icon size={15} /></a>)}
            </div>
          </div>
        </div>
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <a href="#top" className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 shrink-0 rounded-full border-2 border-[var(--gold)] grid place-items-center bg-[#0E4A37] font-arabic text-2xl text-[#E8C766]">ق</div>
            <div className="min-w-0 leading-tight">
              <p className="font-display text-[17px] sm:text-xl text-[#F4E3A1] [overflow-wrap:anywhere]">Hafiz Ali Online Quran Academy</p>
              <p className="text-[10px] sm:text-[11px] tracking-[0.22em] uppercase text-[#9DBFB0]">Learn • Recite • Memorise</p>
            </div>
          </a>
          <nav className="hidden lg:flex items-center gap-5 text-sm font-semibold text-[#CDE3D6]">
            {nav.map(([label, href]) => <a key={href} href={href} className="hover:text-[#E8C766]">{label}</a>)}
            <a href="#trial" className="btn-gold rounded-full px-4 py-2 text-sm">Book Free Trial</a>
          </nav>
          <button onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Close menu" : "Open menu"} className="lg:hidden w-10 h-10 rounded-lg border border-[var(--line)] grid place-items-center text-[#E8C766]">{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
        {menuOpen && <nav className="lg:hidden border-t border-[var(--line)] px-4 py-3 grid gap-1 bg-[#073325]">
          {nav.map(([label, href]) => <a key={href} href={href} onClick={() => setMenuOpen(false)} className="py-2.5 px-2 rounded-lg hover:bg-white/5 font-semibold">{label}</a>)}
          <a href="#trial" onClick={() => setMenuOpen(false)} className="btn-gold rounded-xl px-4 py-3 text-center mt-1">Book a Free Trial Class</a>
        </nav>}
      </header>

      <main id="top">
        {/* HERO */}
        <section className="pattern relative overflow-hidden">
          <div className="max-w-6xl mx-auto px-4 pt-10 pb-12 sm:pt-16 sm:pb-20 text-center">
            <p className="font-arabic text-4xl sm:text-6xl text-[#E8C766] leading-tight" dir="rtl" lang="ar">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
            <p className="mt-2 text-xs tracking-[0.25em] uppercase text-[#9DBFB0]">In the name of Allah, the Most Gracious, the Most Merciful</p>
            <div className="gold-line w-28 mx-auto my-6" />
            <h1 className="font-display text-[clamp(2rem,7vw,4.2rem)] leading-[1.05] text-[#FFFDF4] [overflow-wrap:anywhere]">Welcome to<br /><span className="text-[#E8C766]">Hafiz Ali Online<br className="sm:hidden" /> Quran Academy</span></h1>
            <p className="max-w-2xl mx-auto mt-5 text-base sm:text-lg text-[#CDE3D6] leading-relaxed">Learn the Holy Quran online with flexible timing and personalised care, from anywhere in the world.</p>
            <div className="mt-7 flex flex-col sm:flex-row justify-center gap-3">
              <a href="#trial" className="btn-gold rounded-full px-7 py-3.5">Book a Free Trial Class</a>
              <a href="#courses" className="btn-outline rounded-full px-7 py-3.5 font-bold">Explore Our Courses</a>
            </div>
            <div className="mt-9 grid grid-cols-2 lg:grid-cols-4 gap-3 max-w-4xl mx-auto">
              {[{ i: Sparkles, t: "Free Trial Class", s: "Try before you decide" }, { i: Clock, t: "Flexible Schedules", s: "Times that suit you" }, { i: Globe2, t: "Students Worldwide", s: "Learn from anywhere" }, { i: BadgeCheck, t: "Clear Monthly Fees", s: "No hidden charges" }].map((f) => (
                <div key={f.t} className="card !rounded-2xl px-3 py-4 text-left"><f.i className="text-[#E8C766]" size={22} /><p className="font-bold mt-2 text-sm">{f.t}</p><p className="text-xs text-[#9DBFB0] mt-0.5">{f.s}</p></div>
              ))}
            </div>
          </div>
        </section>

        {/* COURSES */}
        <section id="courses" className="max-w-6xl mx-auto px-4 py-12 sm:py-16">
          <p className="text-center text-xs tracking-[0.25em] uppercase text-[#E8C766] font-bold">Our Courses</p>
          <h2 className="font-display text-3xl sm:text-5xl text-center mt-3">Six Courses, One Beautiful Journey</h2>
          <p className="text-center text-[#9DBFB0] max-w-2xl mx-auto mt-3">Choose the course that fits your level. Every journey begins with a free trial class.</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
            {courses.map((c) => (
              <article key={c.title} className="card p-5 flex flex-col">
                <div className="flex items-start justify-between"><span className="w-12 h-12 rounded-2xl bg-[var(--gold)]/15 border border-[var(--line)] grid place-items-center text-[#E8C766]"><c.icon size={24} /></span><span className="font-display text-3xl text-[#D4AF37]/30">{c.n}</span></div>
                <span className="chip self-start text-[11px] px-2.5 py-1 text-[#E8C766] mt-4">{c.tag}</span>
                <h3 className="font-display text-2xl mt-3">{c.title}</h3>
                <p className="text-sm text-[#CDE3D6] leading-relaxed mt-2 flex-1 [overflow-wrap:anywhere]">{c.desc}</p>
                <a href="#trial" className="btn-gold rounded-xl px-4 py-3 text-center text-sm mt-5">Book Free Trial</a>
              </article>
            ))}
          </div>
        </section>

        {/* WHY + ABOUT */}
        <section id="why" className="bg-[var(--bg3)] border-y border-[var(--line)] pattern-light">
          <div className="max-w-6xl mx-auto px-4 py-12 sm:py-16 grid lg:grid-cols-2 gap-10 items-start">
            <div>
              <p className="text-xs tracking-[0.25em] uppercase text-[#E8C766] font-bold">Why Choose Us</p>
              <h2 className="font-display text-3xl sm:text-4xl mt-3">Learning That Feels Personal, Calm & Caring</h2>
              <p className="text-[#CDE3D6] leading-relaxed mt-4">At Hafiz Ali Online Quran Academy, every student is known by name, not by number. Lessons are patient, structured and full of encouragement — so children and adults can grow in confidence, love for the Quran and correct recitation.</p>
              <div className="grid sm:grid-cols-2 gap-3 mt-6">{why.map((w) => <div key={w.title} className="rounded-2xl border border-[var(--line)] bg-white/5 p-4"><w.icon className="text-[#E8C766]" size={22} /><h3 className="font-bold mt-2">{w.title}</h3><p className="text-sm text-[#9DBFB0] mt-1">{w.text}</p></div>)}</div>
            </div>
            <div className="card p-6 sm:p-7">
              <p className="text-xs tracking-[0.25em] uppercase text-[#E8C766] font-bold">About Us</p>
              <h2 className="font-display text-3xl mt-3">Online Quran Education for the Whole Family</h2>
              <p className="text-[#CDE3D6] leading-relaxed mt-4">We provide online Quran education for children and adults around the world. From first letters to memorisation, our caring teachers guide each student step by step — with flexible timings, clear fees and a free trial first.</p>
              <div className="gold-line my-5" />
              <h3 className="font-display text-xl text-[#E8C766]">Benefits</h3>
              <ul className="grid sm:grid-cols-2 gap-2.5 mt-4 text-sm">{["Personalised Learning", "Flexible Timing", "Learn From Home", "Every Level Welcome", "Six Courses", "Free Trial First"].map((b) => <li key={b} className="flex gap-2 items-start"><CheckCircle2 size={18} className="text-[#E8C766] shrink-0 mt-0.5" /><span>{b}</span></li>)}</ul>
            </div>
          </div>
        </section>

        {/* TESTIMONIALS */}
        <section className="max-w-6xl mx-auto px-4 py-12 sm:py-16">
          <p className="text-center text-xs tracking-[0.25em] uppercase text-[#E8C766] font-bold">Testimonials</p>
          <h2 className="font-display text-3xl sm:text-4xl text-center mt-3">What Families Say</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
            {(showAllReviews ? testimonials : testimonials.slice(0, 3)).map((t) => (
              <figure key={t.name} className="card p-5"><div className="flex gap-0.5 text-[#E8C766]">{[1, 2, 3, 4, 5].map((s) => <Star key={s} size={16} fill="currentColor" />)}</div><blockquote className="mt-3 text-sm leading-relaxed text-[#E9F2EB] [overflow-wrap:anywhere]">“{t.quote}”</blockquote><figcaption className="mt-4"><p className="font-bold text-sm">{t.name}</p><p className="text-xs text-[#9DBFB0]">{t.role}</p></figcaption></figure>
            ))}
          </div>
          <div className="text-center mt-5"><button onClick={() => setShowAllReviews(!showAllReviews)} className="btn-outline rounded-full px-5 py-2.5 text-sm font-bold">{showAllReviews ? "Show fewer reviews" : "Show all reviews"}</button></div>
        </section>

        {/* FEES */}
        <section id="fees" className="bg-[var(--bg3)] border-y border-[var(--line)]">
          <div className="max-w-6xl mx-auto px-4 py-12 sm:py-16">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div><p className="text-xs tracking-[0.25em] uppercase text-[#E8C766] font-bold">Fee Plans</p><h2 className="font-display text-3xl sm:text-4xl mt-3">Simple, Clear Monthly Fees</h2><p className="text-[#9DBFB0] mt-2">Every plan includes 30-minute lessons.</p></div>
              <label className="text-sm font-bold">Currency<br /><select value={currency} onChange={(e) => setCurrency(e.target.value)} className="field !w-auto mt-1" aria-label="Choose currency">{Object.keys(rates).map((c) => <option key={c} value={c}>{rates[c].label}</option>)}</select></label>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
              {plans.map((p) => (
                <article key={p.name} className={`card p-5 relative ${p.recommended ? "border-[#E8C766] !border-2" : ""}`}>
                  {p.recommended && <span className="absolute -top-3 left-4 bg-[var(--gold)] text-[#0B3D2E] text-[11px] font-extrabold px-3 py-1 rounded-full">RECOMMENDED</span>}
                  <h3 className="font-display text-xl">{p.name}</h3><p className="text-xs text-[#9DBFB0] mt-1">{p.note}</p>
                  <p className="mt-4"><span className="text-4xl font-extrabold text-[#E8C766]">{rate.symbol}{Math.round(p.price * rate.rate)}</span><span className="text-[#9DBFB0] text-sm"> /month</span></p>
                  <ul className="mt-4 space-y-2 text-sm text-[#CDE3D6]"><li className="flex gap-2"><CheckCircle2 size={17} className="text-[#E8C766]" /> 30-minute lessons</li><li className="flex gap-2"><CheckCircle2 size={17} className="text-[#E8C766]" /> {p.classes} classes / month</li><li className="flex gap-2"><CheckCircle2 size={17} className="text-[#E8C766]" /> {p.hours} hours / month</li></ul>
                  <a href={`${WHATSAPP_CHAT}?text=${encodeURIComponent(`Assalam-o-Alaikum! I would like to sign up for the ${p.name} plan.`)}`} target="_blank" rel="noopener" className="btn-gold rounded-xl px-4 py-3 text-center text-sm block mt-5">Sign Up Today</a>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section id="how" className="max-w-6xl mx-auto px-4 py-12 sm:py-16">
          <p className="text-center text-xs tracking-[0.25em] uppercase text-[#E8C766] font-bold">How It Works</p>
          <h2 className="font-display text-3xl sm:text-4xl text-center mt-3">Start in Three Simple Steps</h2>
          <div className="grid md:grid-cols-3 gap-4 mt-8">
            {[{ i: BookOpen, t: "1. Choose Your Course", d: "Pick from our six courses, based on your level and goals." }, { i: CalendarCheck, t: "2. Register for Free Trial", d: "Send the trial form on WhatsApp. We confirm your free class." }, { i: Play, t: "3. Start Your Learning Journey", d: "Meet your teacher, set your schedule and begin learning." }].map((s) => <div key={s.t} className="card p-6 text-center"><s.i size={30} className="mx-auto text-[#E8C766]" /><h3 className="font-display text-xl mt-3">{s.t}</h3><p className="text-sm text-[#CDE3D6] mt-2 leading-relaxed">{s.d}</p></div>)}
          </div>
        </section>

        {/* FORM */}
        <section id="trial" className="max-w-6xl mx-auto px-4 pb-12 sm:pb-16">
          <div className="card overflow-hidden">
            <div className="p-6 sm:p-8 pb-0 text-center"><p className="text-xs tracking-[0.25em] uppercase text-[#E8C766] font-bold">Free Trial</p><h2 className="font-display text-3xl sm:text-4xl mt-3">Book a Free Trial Class</h2><p className="text-[#CDE3D6] mt-2">Your first class is a free trial.</p></div>
            <form onSubmit={submitTrial} className="p-6 sm:p-8 grid sm:grid-cols-2 gap-4">
              <label className="text-sm font-bold">Student Name *<input className="field mt-1.5" value={form.student} onChange={(e) => set("student", e.target.value)} placeholder="Full name" required /></label>
              <label className="text-sm font-bold">Parent / Guardian Name *<input className="field mt-1.5" value={form.parent} onChange={(e) => set("parent", e.target.value)} placeholder="Parent or guardian" required /></label>
              <label className="text-sm font-bold">Student Age *<input className="field mt-1.5" type="number" min="3" max="100" value={form.age} onChange={(e) => set("age", e.target.value)} placeholder="Age in years" required /></label>
              <label className="text-sm font-bold">Country *<input className="field mt-1.5" value={form.country} onChange={(e) => set("country", e.target.value)} placeholder="Your country" required /></label>
              <label className="text-sm font-bold">WhatsApp Number *<input className="field mt-1.5" type="tel" value={form.whatsapp} onChange={(e) => set("whatsapp", e.target.value)} placeholder="+92 ..." required /></label>
              <label className="text-sm font-bold">Email *<input className="field mt-1.5" type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="you@example.com" required /></label>
              <label className="text-sm font-bold">Select Course *<select className="field mt-1.5" value={form.course} onChange={(e) => set("course", e.target.value)} required><option value="">Choose a course</option>{courses.map((c) => <option key={c.title}>{c.title}</option>)}</select></label>
              <label className="text-sm font-bold">Preferred Weekly Schedule *<select className="field mt-1.5" value={form.schedule} onChange={(e) => set("schedule", e.target.value)} required><option value="">Choose a plan</option>{plans.map((p) => <option key={p.name}>{p.name}</option>)}</select></label>
              <label className="sm:col-span-2 text-sm font-bold">Preferred Class Time and Time Zone *<input className="field mt-1.5" value={form.time} onChange={(e) => set("time", e.target.value)} placeholder="e.g. 6:00 PM, Pakistan Time" required /></label>
              <label className="sm:col-span-2 text-sm font-bold">Additional Message<textarea className="field mt-1.5 min-h-[90px]" value={form.message} onChange={(e) => set("message", e.target.value)} placeholder="Anything we should know?" /></label>
              {saveStatus && <p role="status" className="sm:col-span-2 rounded-xl bg-white/5 border border-[var(--line)] px-4 py-3 text-sm text-[#F4E3A1] [overflow-wrap:anywhere]">{saveStatus}</p>}
              <button type="submit" disabled={busy} className="sm:col-span-2 btn-gold rounded-xl px-6 py-4 flex items-center justify-center gap-2 disabled:opacity-60"><MessageCircle size={19} />{busy ? "Saving & opening WhatsApp…" : "Send via WhatsApp"}</button>
              <p className="sm:col-span-2 text-center text-xs text-[#9DBFB0]">This opens WhatsApp with your details ready to send to +92 313 6793394.</p>
            </form>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="max-w-4xl mx-auto px-4 pb-12 sm:pb-16">
          <p className="text-center text-xs tracking-[0.25em] uppercase text-[#E8C766] font-bold">FAQ</p>
          <h2 className="font-display text-3xl sm:text-4xl text-center mt-3">Common Questions</h2>
          <div className="mt-7 space-y-3">{faqs.map((f, i) => (
            <div key={f.q} className="card !rounded-2xl overflow-hidden"><button onClick={() => setOpenFaq(openFaq === i ? null : i)} aria-expanded={openFaq === i} className="w-full flex items-center justify-between gap-3 px-5 py-4 text-left font-bold">{f.q}<ChevronDown size={19} className={`shrink-0 text-[#E8C766] transition ${openFaq === i ? "rotate-180" : ""}`} /></button>{openFaq === i && <p className="px-5 pb-5 text-sm leading-relaxed text-[#CDE3D6] [overflow-wrap:anywhere]">{f.a}</p>}</div>
          ))}</div>
        </section>

        {/* CONTACT */}
        <section id="contact" className="bg-[var(--bg3)] border-t border-[var(--line)] pattern-light">
          <div className="max-w-6xl mx-auto px-4 py-12 text-center">
            <p className="text-xs tracking-[0.25em] uppercase text-[#E8C766] font-bold">Contact Us</p>
            <h2 className="font-display text-3xl sm:text-4xl mt-3">Let’s Begin Your Quran Journey</h2>
            <p className="text-[#CDE3D6] mt-3">WhatsApp: <strong className="text-white">+92 313 6793394</strong></p>
            <a href={WHATSAPP_CHAT} target="_blank" rel="noopener" className="btn-gold inline-flex items-center gap-2 rounded-full px-7 py-3.5 mt-5"><MessageCircle size={19} /> Message on WhatsApp</a>
            <div className="mt-8"><p className="text-xs tracking-[0.2em] uppercase text-[#9DBFB0] font-bold mb-3">Follow Us</p><div className="flex flex-wrap justify-center gap-2.5">{socials.map((s) => <a key={s.label} href={s.href} target="_blank" rel="noopener" className="chip px-4 py-2.5 text-sm font-bold inline-flex items-center gap-2 text-[#F4E3A1]"><s.icon size={17} />{s.label}</a>)}</div></div>
          </div>
        </section>
      </main>

      <footer className="bg-[#05281E] border-t border-[var(--line)]">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
            <div><p className="font-display text-lg text-[#F4E3A1]">Hafiz Ali Online Quran Academy</p><p className="text-xs text-[#9DBFB0] mt-1">Learn • Recite • Memorise — from anywhere in the world.</p></div>
            <div className="flex gap-2">{socials.map((s) => <a key={s.label} href={s.href} target="_blank" rel="noopener" aria-label={s.label} className="w-9 h-9 rounded-full border border-[var(--line)] grid place-items-center text-[#E8C766] hover:bg-[var(--gold)] hover:text-[#0B3D2E]"><s.icon size={16} /></a>)}</div>
          </div>
          <div className="gold-line my-5" /><p className="text-center text-xs text-[#9DBFB0]">© 2026 Hafiz Ali Online Quran Academy. All rights reserved.</p>
          {savedCount > 0 && <p className="text-center text-[11px] text-[#9DBFB0] mt-2">{savedCount} trial {savedCount === 1 ? "request" : "requests"} saved in the academy records.</p>}
        </div>
      </footer>

      {/* FLOATING BUTTONS */}
      <div className="fixed bottom-4 left-4 z-40">
        {socialOpen && <div className="mb-2 w-60 rounded-2xl border border-[var(--line)] bg-[#073325] shadow-2xl p-3"><p className="text-xs tracking-[0.18em] uppercase text-[#E8C766] font-bold px-1 pb-2">Follow Us</p>{socials.map((s) => <a key={s.label} href={s.href} target="_blank" rel="noopener" className="flex items-center gap-3 px-2 py-2.5 rounded-xl hover:bg-white/5"><span className="w-8 h-8 rounded-full bg-[var(--gold)]/15 grid place-items-center text-[#E8C766]"><s.icon size={16} /></span><span><span className="block text-sm font-bold">{s.label}</span><span className="block text-[11px] text-[#9DBFB0] [overflow-wrap:anywhere]">{s.note}</span></span></a>)}</div>}
        <button onClick={() => setSocialOpen(!socialOpen)} aria-expanded={socialOpen} className="h-12 px-4 rounded-full bg-[#E8C766] text-[#0B3D2E] font-extrabold text-sm shadow-2xl flex items-center gap-2"><Users size={18} /> Follow Us</button>
      </div>
      <a href={WHATSAPP_CHAT} target="_blank" rel="noopener" aria-label="Chat on WhatsApp" className="fixed bottom-4 right-4 z-40 w-14 h-14 rounded-full bg-[#25D366] text-white grid place-items-center shadow-2xl border-2 border-white/30"><MessageCircle size={27} /></a>
    </div>
  );
}
